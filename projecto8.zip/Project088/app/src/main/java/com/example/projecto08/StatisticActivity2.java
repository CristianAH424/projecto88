package com.example.projecto08;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.projecto08.models.cardboard;
import com.example.projecto08.models.plastic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class StatisticActivity2 extends AppCompatActivity {
    TextView totalCarton,totalplastic,total_pay,max_carton_month,
            max_plastic_month,max_carton_quantity,max_plastic_quantity;

    Button more;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistic2);

        totalCarton = findViewById(R.id.textViewTotalCarton);
        totalplastic = findViewById(R.id.textViewTotalPlastic);
        total_pay=findViewById(R.id.textViewTotalPay);
        max_carton_month=findViewById(R.id.textViewMonthMaxCarton);
        max_carton_quantity=findViewById(R.id.textViewMaxCartonQuantity);
        max_plastic_month=findViewById(R.id.textViewMonthMaxPlastico);
        max_plastic_quantity=findViewById(R.id.textViewMaxPlasticQuantity);
        more=findViewById(R.id.btnMore);


        Intent receive = getIntent();
        String idUser = receive.getStringExtra("idUser");

        File CartonFile = new File(getFilesDir(), "cardboard.txt");
        File plasticFile = new File(getFilesDir(), "plastic.txt");

        ArrayList<cardboard> list_cardboard = listCarton(CartonFile, idUser);
        ArrayList<plastic> list_plastic = listplastic(plasticFile, idUser);

        totalconsumecarton(list_cardboard);
        totalconsumeplastic(list_plastic);

        int total= totalPaycarton(list_cardboard)+totalPayplastic(list_plastic);
        total_pay.setText("$ "+total);




    }
    public int totalPaycarton(ArrayList<cardboard>list){
        int pay=0;
        for (cardboard i: list){
            pay+=i.getPrice();
        }
        return pay;
    }
    public int totalPayplastic(ArrayList<plastic>list){
        int pay=0;
        for (plastic i: list){
            pay+=i.getPrice();
        }
        return pay;
    }


        public void totalconsumecarton(ArrayList<cardboard>list){
            int total = 0;
            String month="";
            int max=0;
            for (cardboard i:list){
                total+=i.getQuantity();
                if (max<i.getQuantity()){
                    max=i.getQuantity();
                    month=i.getMonth();
                }
            }
            totalCarton.setText(total+" kl");
            max_carton_quantity.setText(max+" kl");
            max_carton_month.setText(month);
        }
    public void totalconsumeplastic(ArrayList<plastic>list){
        int total=0;
        String month="";
        int max=0;
        for (plastic i:list){
            total+=i.getQuantity();
            if (max<i.getQuantity()){
                max=i.getQuantity();
                month=i.getMonth();
            }
        }
        totalplastic.setText(total+" Kl");
        max_plastic_quantity.setText(max+" Kl");
        max_plastic_month.setText(month);
    }


    public ArrayList<cardboard> listCarton(File carton,String user) {
        ArrayList<cardboard> list = new ArrayList<>();
        try {
            FileReader fileReader = new FileReader(carton);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String cadena;

            while ((cadena = bufferedReader.readLine())!= null) {
                String[] data = cadena.split(",");

                String serial = data[0];
                int quantity = Integer.parseInt(data[1]);
                int price = Integer.parseInt(data[2]);
                String month = data[3];
                String idUser = data[4];
                if (data[4].equals(user)) {
                    cardboard obj = new cardboard(serial, quantity, price, month, idUser);
                    list.add(obj);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public ArrayList<plastic> listplastic(File plastic, String user){
        ArrayList<plastic> list= new ArrayList<>();
        try {
            FileReader reader= new FileReader(plastic);
            BufferedReader bufferedReader=new BufferedReader(reader);
            String cadena;
            while ((cadena=bufferedReader.readLine())!=null){
                String [] data= cadena.split(",");
                if(data[4].equals(user)){
                    String serial= data[0];
                    int quantity= Integer.parseInt(data[1]);
                    int price= Integer.parseInt(data[2]);
                    String month= data[3];
                    String idUser= data[4];

                    plastic obj= new plastic(serial,quantity,price,month,idUser);
                    list.add(obj);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }



}



